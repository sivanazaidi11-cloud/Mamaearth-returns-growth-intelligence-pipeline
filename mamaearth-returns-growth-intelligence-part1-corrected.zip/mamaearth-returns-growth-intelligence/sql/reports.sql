.headers on
.mode column

-- ============================================================
-- Part 1 — SQL Relational Layer & Reporting
-- Reports are run against the raw loaded data. No deduplication,
-- casing normalization, or analytical imputation is performed here.
-- ============================================================

-- (a) Order totals
-- Exact output: total_orders=180, total_revenue=99860.20, avg_order_value=554.78
SELECT
    COUNT(*) AS total_orders,
    ROUND(SUM(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2) AS total_revenue,
    ROUND(AVG(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2) AS avg_order_value
FROM orders AS o
JOIN products AS p ON p.product_id = o.product_id;

-- (b) COUNT(*) vs COUNT(column)
-- Exact output: count_all=180, count_rating=165, difference=15
SELECT
    COUNT(*) AS count_all,
    COUNT(rating) AS count_rating,
    COUNT(*) - COUNT(rating) AS difference
FROM orders;

-- (c1) LEFT JOIN: customers with zero orders
-- Exact output: C045 | Vihaan
SELECT
    c.customer_id,
    c.name
FROM customers AS c
LEFT JOIN orders AS o ON o.customer_id = c.customer_id
GROUP BY c.customer_id, c.name
HAVING COUNT(o.order_id) = 0;

-- (c2) Independent NOT IN validation
-- Exact output: C045 | Vihaan
SELECT
    customer_id,
    name
FROM customers
WHERE customer_id NOT IN (SELECT DISTINCT customer_id FROM orders);

-- (d) GROUP BY + HAVING: cities with return rate > 20%
-- Exact output:
-- Jaipur    | 19 | 8 | 42.1
-- Lucknow   | 49 | 15 | 30.6
-- Bangalore | 33 | 8 | 24.2
SELECT
    c.city,
    COUNT(o.order_id) AS total_orders,
    SUM(o.returned) AS returned_orders,
    ROUND(100.0 * SUM(o.returned) / COUNT(o.order_id), 1) AS return_rate_pct
FROM orders AS o
JOIN customers AS c ON c.customer_id = o.customer_id
GROUP BY c.city
HAVING return_rate_pct > 20
ORDER BY return_rate_pct DESC;

-- (e1) Top 5 customers by total spend
-- Tie-break comment: customer_id ASC makes tied spend ranks deterministic.
-- Exact output:
-- C043 | Reyansh | 12920.00
-- C026 | Isha    | 8371.60
-- C008 | Meera   | 4564.60
-- C011 | Arjun   | 4111.00
-- C042 | Sanya   | 3785.00
SELECT
    c.customer_id,
    c.name,
    ROUND(SUM(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2) AS total_spend
FROM orders AS o
JOIN products AS p ON p.product_id = o.product_id
JOIN customers AS c ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name
ORDER BY total_spend DESC, c.customer_id ASC
LIMIT 5;

-- (e2) Ranks 3–5 using LIMIT 3 OFFSET 2, without re-deriving the top 5.
-- Exact output: C008 | Meera | 4564.60; C011 | Arjun | 4111.00; C042 | Sanya | 3785.00
SELECT
    c.customer_id,
    c.name,
    ROUND(SUM(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2) AS total_spend
FROM orders AS o
JOIN products AS p ON p.product_id = o.product_id
JOIN customers AS c ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name
ORDER BY total_spend DESC, c.customer_id ASC
LIMIT 3 OFFSET 2;

-- (f) Three-table JOIN + GROUP BY by category
-- Exact output:
-- Haircare     | 54 | 44956.10
-- Skincare     | 60 | 27346.00
-- Babycare     | 30 | 16805.00
-- PersonalCare | 36 | 10753.10
SELECT
    p.category,
    COUNT(o.order_id) AS order_count,
    ROUND(SUM(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2) AS category_revenue
FROM orders AS o
JOIN products AS p ON p.product_id = o.product_id
JOIN customers AS c ON c.customer_id = o.customer_id
GROUP BY p.category
ORDER BY category_revenue DESC;

-- (g) LIKE pattern match
-- Exact output: 10 customers whose names start with A.
SELECT
    customer_id,
    name
FROM customers
WHERE name LIKE 'A%'
ORDER BY customer_id;

-- (h) DISTINCT acquisition sources
-- Exact output: Ad, Organic, Referral, Social
SELECT DISTINCT acquisition_source
FROM customers
ORDER BY acquisition_source;

-- (i) ALTER TABLE + UPDATE with CASE
ALTER TABLE customers ADD COLUMN loyalty_tier VARCHAR(10);

UPDATE customers
SET loyalty_tier = CASE
    WHEN city_tier = 1 THEN 'Gold'
    ELSE 'Silver'
END;

-- Exact output: Gold | 28; Silver | 17
SELECT
    loyalty_tier,
    COUNT(*) AS customer_count
FROM customers
GROUP BY loyalty_tier
ORDER BY loyalty_tier;
