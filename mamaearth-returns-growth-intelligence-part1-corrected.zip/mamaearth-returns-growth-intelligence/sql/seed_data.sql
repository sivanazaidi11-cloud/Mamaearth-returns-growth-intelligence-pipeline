.mode csv
.headers on

.import data/customers.csv customers
.import data/products.csv products
.import data/orders.csv orders

-- SQLite .import loads blank CSV cells as empty strings. Convert those
-- deliberate blanks to SQL NULL before running any report.
UPDATE orders SET discount_pct = NULL WHERE discount_pct = '';
UPDATE orders SET rating = NULL WHERE rating = '';

-- Required Part 1 load checks:
-- SELECT COUNT(*) FROM customers; -- 45
-- SELECT COUNT(*) FROM products;  -- 16
-- SELECT COUNT(*) FROM orders;    -- 180
